export class Player {

    constructor(scene, id, x, y, sprite, spriteSizeX, spriteSizeY, immovable, collider) {
        this.id = id;
        this.scene = scene;
        this.health = 100;
        this.speed = 4;
        this.actionable = true;
        this.invulnerable = false;
        this.colliding = false;
        this.x = x;
        this.y = y;

        this.sprite = scene.physics.add.sprite(x, y, sprite);
        this.sprite.setDisplaySize(spriteSizeX, spriteSizeY);
        this.sprite.setImmovable(immovable);
        this.sprite.setCollideWorldBounds(collider);
    }
}