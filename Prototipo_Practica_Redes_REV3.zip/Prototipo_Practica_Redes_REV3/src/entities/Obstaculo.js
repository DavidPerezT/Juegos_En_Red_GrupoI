export class Obstaculo {

    constructor(scene, x, y, sprite, spriteSizeX, spriteSizeY, immovable, collider) {
        this.scene = scene;
        this.invulnerable = true;
        this.x = x;
        this.y = y;

        this.sprite = scene.physics.add.sprite(x, y, sprite);
        this.sprite.setDisplaySize(spriteSizeX, spriteSizeY);

        this.sprite.setImmovable(immovable);
        this.sprite.setCollideWorldBounds(collider);
    }
}