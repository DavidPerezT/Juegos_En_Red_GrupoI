import Phaser from 'phaser';

export class PauseScene extends Phaser.Scene {
    constructor() {
        super('PauseScene');
    }

    create() {
        this.add.rectangle(400,300,800,600,0x000000,0.7);

        this.add.text(400, 150, 'Estas pausado', {
            fontSize: '64px',
            color: '#ffffff'
        }).setOrigin(0.5);

        const resume = this.add.text(400, 320, 'Resumir', {
            fontSize: '32px',
            color: '#00ff00'
        }).setOrigin(0.5)
            .setInteractive({ useHandCursor: true })
            .on('pointerover', () => resume.setStyle({ color: '#ffff00' }))
            .on('pointerout', () => resume.setStyle({ color: '#00ff00' }))
            .on('pointerdown', () => { 
                this.scene.stop();
                this.scene.resume('GameScene');
            });
            
        const returnMenu = this.add.text(400, 380, 'Volver a menu', {
            fontSize: '32px',
            color: '#00ff00'
        }).setOrigin(0.5)
            .setInteractive({ useHandCursor: true })
            .on('pointerover', () => returnMenu.setStyle({ color: '#ffff00' }))
            .on('pointerout', () => returnMenu.setStyle({ color: '#00ff00' }))
            .on('pointerdown', () => { 
                this.scene.stop('GameScene');
                this.scene.start('MenuScene');
            });

    }
}
