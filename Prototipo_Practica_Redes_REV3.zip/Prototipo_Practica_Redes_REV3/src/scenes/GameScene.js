import Phaser, { RIGHT } from 'phaser';
import { Player } from '../entities/Player';
import { Obstaculo } from '../entities/Obstaculo';

export class GameScene extends Phaser.Scene {
    constructor() {
        super('GameScene');
    }

    init() {
    }

    preload() {
        // Cargar recursos
        // Sprite héroe
        this.load.image('hero_test','assets/images/hero_test.png')
        // Sprite lobo
        this.load.image('werewolf_test','assets/images/werewolf_test.png')
        // Sprite obstáculo
        this.load.image('obstaculo_sprite','assets/images/obstaculo.png')

        // Sonido de hit
        this.load.audio('hit', 'assets/audio/hit.mp3');
    }

    create() {
        // Texto
        this.p1health = 0;
        this.p2health = 0;

        // Jugadores
        this.player1 = new Player(this, 'player1', 400, 300, 'hero_test', 30, 30, false, true);
        this.player2 = new Player(this, 'player2', 400, 50, 'werewolf_test', 100, 50, false, true);

        // Obstaculos
        this.Obstaculos = [];

        //Velocidad héroe
        this.player1.speed = 150;

        //Booleano para controlar el aparecimiento de obstaculos
        this.canSpawnObstacles = true;

        //Keybinds
        const Keys = Phaser.Input.Keyboard.KeyCodes;
        this.HeroControls = {
            up: this.input.keyboard.addKey(Keys.W),
            left: this.input.keyboard.addKey(Keys.A),
            down: this.input.keyboard.addKey(Keys.S),
            right: this.input.keyboard.addKey(Keys.D),
            attack: this.input.keyboard.addKey(Keys.Q),
            defend: this.input.keyboard.addKey(Keys.E),
        }

        this.WerewolfControls = {
            grab: this.input.keyboard.addKey(Keys.UP),
            rotLeft: this.input.keyboard.addKey(Keys.LEFT),
            laser: this.input.keyboard.addKey(Keys.DOWN),
            rotRight: this.input.keyboard.addKey(Keys.RIGHT),
            slashLeft: this.input.keyboard.addKey(Keys.N),
            slashRight: this.input.keyboard.addKey(Keys.M),
        }

        // Scores
        this.p1health = this.add.text(200, 50, this.player1.health.toString(), { fontSize: '48px' }).setOrigin(0.5);
        this.p2health = this.add.text(600, 50, this.player2.health.toString(), { fontSize: '48px' }).setOrigin(0.5);

        // Collisions on all sides 
        this.physics.world.setBoundsCollision(false, false, true, true);

        //fisicas del jugador
        this.physics.add.existing(this.player1.sprite,true);

        //Pausar con esc
        this.input.keyboard.on('keydown-ESC', () => {
            this.scene.pause();
            this.scene.launch('PauseScene');
        });
    }

    updateHealth() {
        this.p1health.setText(this.player1.health.toString());
        this.p2health.setText(this.player2.health.toString());

        if (this.player1.health <= 0 || this.player2.health <= 0) {
            this.scene.start('MenuScene');
        } 
    }

    // EndLag
    setDelay(player,ms){
        
        player.actionable = false;
        
        this.time.delayedCall(ms,() =>{
            player.actionable = true;
            console.log(player.actionable);
        })
        
    }

    // Ataque de zarpazo de lobo
    slash(direction){
        let offX; 
        let Polygon;
        let PolygonAABB;
        //Telegraph
        if(direction == 'left')
            {
                offX = -400;
                Polygon = this.add.polygon(550, 0, 
                    [   
                        (offX), 0, //1
                        (offX/3), 0,
                        0, 2000,
                        (offX/1.5), 2000,
                    ]
                    ,0xff0000,0.5);
    
            }
        if(direction == 'right')
            {
                offX = 400;
                Polygon = this.add.polygon(650, 0, 
                    [   
                        (offX), 0, //1
                        (offX/3), 0,
                        0, 2000,
                        (offX/1.5), 2000,
                    ]
                    ,0xff0000,0.5);
            }

            

        console.log(direction);
        this.setDelay(this.player2,2000);

        //Comprobación de hitbox
        this.time.delayedCall(1300,() =>{
            console.log("Pasen versículos de la biblia");
            PolygonAABB = Phaser.Geom.Polygon.GetAABB(Polygon.geom);
            console.log(PolygonAABB);

            if(direction == 'left'){
                if(this.player1.x < PolygonAABB.x + PolygonAABB.width + 330){
                    console.log(this.player1.x,' < ',PolygonAABB.x + PolygonAABB.width + 330);
                    if(this.player1.invulnerable == false){
                        console.log("ClawHit", this.player1.invulnerable);
                        this.player1.health -= 20;
                    }
                }
            }

            if(direction == 'right'){
                if(this.player1.x > PolygonAABB.x + 490){
                    console.log(this.player1.x,' > ',PolygonAABB.x + 490);
                    if(this.player1.invulnerable == false){
                        console.log("ClawHit");
                        this.player1.health -= 20;
                    }
                }
            }

            console.log(this.player1.health);
            
            //Update health data
            this.updateHealth();

            Polygon.destroy();
        })
        
    }

    // Ataque del héroe
    attack(){
        let Hitbox;

        Hitbox = this.add.rectangle(this.player1.x, this.player1.y-60, 120 , 60, 0xff0000, 0.5);
        console.log(Hitbox.x,Hitbox.y);
        console.log(this.player2.x,this.player2.y);

        // Incluir el sprite por aqui

        this.setDelay(this.player1,500);

        if(Hitbox.y - 50 <= this.player2.y){
            console.log("Y hit");
            if(this.player2.x >= Hitbox.x - 120/2 && this.player2.x <= Hitbox.x + 120/2){
                this.player2.health -= 10;
                console.log("hit");
            }
        }

        //Update health data
        this.updateHealth();

        Hitbox.destroy();
    }

    laser(){
        let smallLaser ,smallLaserHitbox ,smallHitboxX,smallHitboxY;
        let bigLaser, bigLaserHitbox, bigHitboxX, bigHitboxY;;

        this.setDelay(this.player2,1000);

        smallLaser = this.add.rectangle(this.player2.x, this.player2.y, 20 , 1200, 0xff00ff, 0.1);
        smallLaser.setRotation(this.player2.sprite.rotation);

        smallHitboxX = 400 - Math.tan(this.player2.sprite.rotation) * (this.player1.y-this.player2.y);
        smallHitboxY = this.player1.y;

        console.log(smallHitboxX,smallHitboxY,this.player2.sprite.rotation);
        smallLaserHitbox = this.add.rectangle(smallHitboxX,smallHitboxY,30,30,0x00ff00,1);
        this.physics.add.existing(smallLaserHitbox);
        
        this.physics.add.collider(smallLaserHitbox,this.player1.sprite,() =>{

            if(!this.player1.invulnerable){
                this.player1.health -= 5;
                smallLaserHitbox.destroy();
                console.log("Small laser hit");
                //Update health data
                this.updateHealth();
            }
        });

        this.time.delayedCall(700,() =>{
            smallLaser.destroy();
            smallLaserHitbox.destroy();

            bigLaser = this.add.rectangle(this.player2.x, this.player2.y, 100 , 1200, 0xff0000, 0.1);
            bigLaser.setRotation(this.player2.sprite.rotation);

            bigHitboxX = 400 - Math.tan(this.player2.sprite.rotation) * (this.player1.y-this.player2.y);
            bigHitboxY = this.player1.y;

            bigLaserHitbox = this.add.rectangle(bigHitboxX,bigHitboxY,120,120,0x00ffff,1);
            this.physics.add.existing(bigLaserHitbox);

            this.physics.add.collider(bigLaserHitbox,this.player1.sprite,() =>{

                if(!this.player1.invulnerable){
                    this.player1.health -= 15;
                    console.log("Big laser hit");
                    bigLaserHitbox.destroy();
                    //Update health data
                    this.updateHealth();
                }

            });

            this.time.delayedCall(300,() =>{
                bigLaser.destroy();
                bigLaserHitbox.destroy();
            });
        });

    }

    grab(){
        let innerHitbox, outerHitbox;

        this.setDelay(this.player2,1500);

        innerHitbox = this.add.rectangle(this.player2.x, this.player2.y+100, 200 , 100, 0xff0000, 0.6);
        outerHitbox = this.add.rectangle(this.player2.x, this.player2.y+100, 600 , 350, 0xff0000, 0.3);

        this.physics.add.existing(innerHitbox);
        this.physics.add.existing(outerHitbox);

        this.time.delayedCall(1200,() =>{

            this.physics.add.collider(innerHitbox,this.player1.sprite,() =>{

                this.player1.health -= 15;
                innerHitbox.destroy();
                outerHitbox.destroy();
                console.log("Inner grab hit");
                //Update health data
                this.updateHealth();
                
            }); 

            this.physics.add.collider(outerHitbox,this.player1.sprite,() =>{

                this.player1.health -= 5;
                innerHitbox.destroy();
                outerHitbox.destroy();
                console.log("Outer grab hit");
                //Update health data
                this.updateHealth();
                
            }); 
            this.time.delayedCall(200,() =>{

                innerHitbox.destroy();
                outerHitbox.destroy();
                console.log("No grab hit");

            });
        });
    }

    addObstacles(numberToAdd){
        for(let i = 0; i < numberToAdd; i++){
            let SpawnXRandom = (Math.random() * 600) + 80;
            let SpawnYRandom = (Math.random() * 400) + 100;

            let nuevoObstaculo = new Obstaculo(this, SpawnXRandom, SpawnYRandom, 'obstaculo_sprite', 40,40, true, true);

            this.Obstaculos.push(nuevoObstaculo);
        }
        console.log("añadidos ",numberToAdd, " obstaculos")
        this.canSpawnObstacles = false;

        this.time.delayedCall(10000,() =>{
            this.canSpawnObstacles = true;
            for(let o = 0; o < numberToAdd; o++){
                let thisObstaculo = this.Obstaculos.pop();
                thisObstaculo.sprite.destroy();
                thisObstaculo = null;
            }
            console.log("Spawnwave disponible");
        });
    }

    checkBoxCollisions(boxes, delta){
        let colMarginX;
        let colMarginY;

        for(let i = 0; i < boxes.length; i++){

            if(this.player1.x + 15 > boxes[i].x - 18 && this.player1.x - 15 < boxes[i].x + 18){

                console.log(" xbox collision with box", i, boxes[i].x);
                colMarginX = this.player1.x - boxes[i].x;

                if(this.player1.y + 15 > boxes[i].y - 16 && this.player1.y - 15 < boxes[i].y + 16){
                    console.log(" ybox collision with box", i, boxes[i].y);
                    
                    colMarginX = this.player1.x - boxes[i].x;
                    colMarginY = this.player1.y - boxes[i].y;
                    //this.player1.colliding = true;
                    console.log("margenes: ",colMarginX,colMarginY);
                }
            }
        }
        if(Math.abs(colMarginX) > Math.abs(colMarginY) ){
            //Colisionando por la derecha
            if(colMarginX > 0){
                this.player1.x += this.player1.speed* (delta/1000);
                this.player1.sprite.x += this.player1.speed* (delta/1000);
            }
            //Colisionando por la izquierda
            if(colMarginX < 0){
                this.player1.x -= this.player1.speed* (delta/1000);
                this.player1.sprite.x -= this.player1.speed* (delta/1000);
            }
            console.log("player x: ",this.player1.x,"sprite x: ",this.player1.sprite.x);
        }
        else if (Math.abs(colMarginX) < Math.abs(colMarginY) ){
            //Colisionando por abajo
            if(colMarginY > 0){
                this.player1.y += this.player1.speed* (delta/1000);
                this.player1.sprite.y += this.player1.speed* (delta/1000);
            }
            //Colisionando por arriba
            if(colMarginY < 0){
                this.player1.y -= this.player1.speed* (delta/1000);
                this.player1.sprite.y -= this.player1.speed* (delta/1000);
            }
            console.log("player y: ",this.player1.y,"sprite y: ",this.player1.sprite.y);
        }
    }

    update(time, delta) {
        this.player1.colliding = false;

        let random = Math.random() * 100;
        let spawnWave = 0;

        //Collision checks
        this.checkBoxCollisions(this.Obstaculos,delta);

        // Hero controls
        if(this.player1.actionable && !this.player1.colliding){
        if(this.HeroControls.up.isDown)
        {
            this.player1.y -= this.player1.speed * (delta/1000);
            this.player1.sprite.y -=this.player1.speed * (delta/1000);
            console.log(this.player1.y,this.player1.sprite.y);
        }
        if(this.HeroControls.down.isDown)
        {
            this.player1.y += this.player1.speed* (delta/1000);
            this.player1.sprite.y +=this.player1.speed* (delta/1000);
            console.log(this.player1.y,this.player1.sprite.y);
        }
        if(this.HeroControls.left.isDown)
        {
            this.player1.x -= this.player1.speed* (delta/1000);
            this.player1.sprite.x -=this.player1.speed* (delta/1000);
            console.log(this.player1.x,this.player1.sprite.x);
        }
        if(this.HeroControls.right.isDown)
        {
            this.player1.x += this.player1.speed* (delta/1000);
            this.player1.sprite.x +=this.player1.speed* (delta/1000);
            console.log(this.player1.x,this.player1.sprite.x);
        }
        if(this.HeroControls.attack.isDown){
            console.log("Hero attack");
            this.attack();
        }
        if(this.HeroControls.defend.isDown){
            console.log("Hero defend");
            this.player1.invulnerable = true;
            this.setDelay(this.player1,2000);
            //Invulnerable por 1 segundos
            this.time.delayedCall(1000,() =>{
                console.log("No longer invul");
                this.player1.invulnerable = false;
            })
        }
        }

        // Werewolf controls
        if(this.player2.actionable){
        if(this.WerewolfControls.grab.isDown)
        {
            console.log("Werewold grab");
            this.grab();
        }

        if(this.WerewolfControls.rotLeft.isDown)
            {
                if(this.player2.sprite.rotation <= Phaser.Math.DegToRad(90)){
                    console.log("Werewold rot left");
                    console.log(Phaser.Math.RadToDeg(this.player2.sprite.rotation));
                    this.player2.sprite.rotation += Phaser.Math.DegToRad(27 * (delta/1000));
                }
            }
        if(this.WerewolfControls.rotRight.isDown)
            {
                if(this.player2.sprite.rotation >= Phaser.Math.DegToRad(-90) ){
                    console.log("Werewold rot right");
                    console.log(Phaser.Math.RadToDeg(this.player2.sprite.rotation));
                    this.player2.sprite.rotation -= Phaser.Math.DegToRad(27 * (delta/1000));
                }
            }
        if(this.WerewolfControls.slashLeft.isDown)
        {
            console.log("Werewold slash left");
            this.slash('left');
            
        }
        if(this.WerewolfControls.slashRight.isDown)
        {
            console.log("Werewold slash right");
            this.slash('right');
        }
        if(this.WerewolfControls.laser.isDown)
        {
            console.log("Werewolf laser");
            this.laser();
        }

        }

        //Control de aparecimiento de obstaculos
        if(this.canSpawnObstacles){
            console.log(random+this.player2.health);
            if(random + this.player2.health <= 160){
                spawnWave += 1;
            }
            if(random + this.player2.health <= 120){
                spawnWave += 1;
            }
            if(random + this.player2.health <= 80){
                spawnWave += 1;
            }
            if(random + this.player2.health <= 50){
                spawnWave += 1;
            }
            if(random + this.player2.health <= 30){
                spawnWave += 1;
            }

            this.addObstacles(spawnWave);
        }
    
    }
}
